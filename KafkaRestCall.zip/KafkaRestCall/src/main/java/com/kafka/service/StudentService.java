package com.kafka.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.kafka.model.StudentDTO;

@Service
public class StudentService {
	
	@Autowired
	private KafkaTemplate<String, StudentDTO> kafkaTemplate;
	
	public String sendMessage(List<StudentDTO> studentList,String topic) {
		for (StudentDTO studentDTO : studentList) {
			ListenableFuture<SendResult<String, StudentDTO>> future=kafkaTemplate.send(topic,studentDTO);
			future.addCallback(new ListenableFutureCallback<SendResult<String, StudentDTO>>() {

				@Override
				public void onSuccess(SendResult<String, StudentDTO> result) {
					// TODO Auto-generated method stub
					System.out.println(result.getProducerRecord().value().getName()+" published to partition:"+result.getRecordMetadata().partition()+" and offset:"+result.getRecordMetadata().offset());
					
				}

				@Override
				public void onFailure(Throwable ex) {
					// TODO Auto-generated method stub
					System.out.println("Publishing of message failed:"+ex.getMessage());
					
				}
			});
		}
		return "Published messages to Kafka";
		
	}

}
