package com.kafka.configuration;

public class KafkaProducerConfiguration {

}
