package com.kafka.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kafka.model.StudentDTO;
import com.kafka.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	private StudentService studentService;
	
	@PostMapping("/addStudents/{topic}")
	public String addStudents(@RequestBody List<StudentDTO> studentList,@PathVariable String topic) {
		return studentService.sendMessage(studentList, topic);
	}
	
	@GetMapping("/getStudent")
	public String getStudent() {
		return "Student data received";
	}

}
